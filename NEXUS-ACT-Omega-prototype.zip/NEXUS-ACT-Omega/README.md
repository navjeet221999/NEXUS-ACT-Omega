# NEXUS-ACT Ω — Governed Autonomous AI Operating System

A front-end competition prototype illustrating risk-adaptive autonomy, multi-agent orchestration, evidence provenance, human approval, and failure recovery.

## Run locally
Open `index.html` in a modern browser. No package installation or build step is required.

## Demo interactions
- Edit the objective and select **Plan** to generate a task graph.
- Select **Inject tool failure** to demonstrate a local failure/recovery state transition.
- Approve or reject the sample consequential action to demonstrate the human gate.

## Scope and limitations
This edition is a client-side UI simulation. It does not call an LLM, MCP server, external API, browser automation, or persistent database. Metrics are illustrative placeholders, not measured performance. Do not represent this demo as a production autonomous agent. Backend adapters, authentication, durable audit storage, policy enforcement, and integration tests are future implementation work.

## Deployment
Import this folder into a GitHub repository and connect the repository to Vercel. Since this is a static HTML prototype, no build command is required and the output is the repository root.
